import streamlit as st

def render_ui():
    st.title("ADI Builder")
    st.markdown("Create AI-powered questions and activities aligned with Bloom's Taxonomy.")
